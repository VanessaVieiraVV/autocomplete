''' Finalmente, as k consultas mais relevantes devem ser inseridas numa lista duplamente encadeada (classe Lista).
Você deve implementar as funções inserirOrdenado e removerFim.
O método inserirOrdenado deve inserir os elementos em ordem de acordo com a função de comparação passada como segundo parâmetro.
Você também deve implementar as funções que permitam imprimir uma lista usando as funções de saída disponíveis
(arquivo ou console).'''

class No:
    def __init__(self,item=None,ant=None,prox=None):
        self.item = item
        self.ant = ant
        self.prox = prox
    
class No:
    def __init__(self,item=None,ant=None,prox=None):
        self.item = item
        self.ant = ant
        self.prox = prox
class Lista :
    def __init__(self):
        self.primeiro = self.ultimo = No()
        self.tamanho = 0
    def __str__(self):
        lista = Lista()
        return lista        
    def size(self):
        return self.tamanho

    def inserirOrdenado(self, item, cmp):
        novo_no = No(item)
        anterior = self.primeiro
        atual = self.item.prox
        while atual != None and cmp(atual.item < item) == -1:
            anterior = atual
            atual = atual.prox
            
        anterior.prox = novo_no
        atual.anterior = novo_no
        novo_no.prox = atual
        novo_no.anterior = anterior
        self.ultimo = atual
        self.tamanho += 1
        


    
    #TODO: implemente    

    def removerFim(self): #fazer que remova até lista duplamente encadeada fique do tamanho de Qtd
        atual = anterior
        self.ultimo = anterior
        self.tamanho -= 1
        

    #TODO: implemente        
    def __str__(self):
        return ""
    
    def __repr__(self):
        return str(self)
