'''1º - Seu trabalho é implementar funções de comparação de termos de consulta
(palavra e peso, cuja estrutura de dados está descrita em Palavra).
Você deve sobrecarregar o operador < para comparar dois objetos
da classe Palavra em ordem lexicográfica dos termos.
Além disso, você deve implementar uma função de comparação por prefixo, e por peso.
Essas funções devem retornar um inteiro negativo, zero,
ou positivo no caso do primeiro
parâmetro ser menor, igual ou maior que o segundo.'''

class Palavra:
    def __init__(self,termo="",peso=-1):
        self.termo = termo
        self.peso = peso
    
    #TODO: implemente
    def __lt__(self,other): #menor que (<)
        if self < other:
            True
    
    def __str__(self): #O valor "informal" como uma string. #Transformar em string?! (Para quê?!)
        return "{0}, {1}".format(self.termo,self.peso)
    
    def __repr__(self): # A representação "oficial" como uma string
        return self.__str__()

#TODO: implemente       
def comparaPorPrefixo(palavra, prefixo):
    if palavra[0].startswith(prefixo):
        return 0
    elif palavra[0] < prefixo :
        return -1
    else :
        return 1    


#TODO: implemente
def comparaPorPeso(palavra1, palavra2):
    if palavra1[1] == palavra2[1] :
        return 0
    elif palavra1[1] < palavra2[1] :
        return -1
    else :
        return 1

