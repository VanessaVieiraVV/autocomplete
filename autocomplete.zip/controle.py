from palavra import *
from lista import Lista
''' Você também deve implementar a classe Controle, que é responsável por fornecer as funcionalidades de carregarDados
e find para carregar o arquivo de consultas e ordená-las (OK), e encontrar a lista de sugestões que casam
com o prefixo informado.
Você também deve implementar dois métodos privados, firstIndexOf e lastIndexOf que
retornam as posições da primeira e última consultas que possuem o prefixo desejado. Essas funções devem ser
usadas para encontrar a parte do vetor de consultas que deve ser processado para encontrar as k consultas mais
relevantes. '''

class Controle:
    def __init__(self):
        self.numeroTermos = 0 #fazer numeroTermos = len(termos)?
        self.termos = list()
        self.dadosCarregados = True
    
    def __apagarTermos(self):
        self.termos = []
        self.numeroTermos = 0
        self.dadosCarregados = False
    
    #TODO: implemente
    def __firstIndexOf(self, prefixo):
        inicio = 0
        fim = self.numeroTermos-1        
        pos = -1
        #TODO: seu codigo aqui
        while inicio <= fim:
            meio = (inicio+fim)//2
            retorno = comparaPorPrefixo(termos[meio], prefixo)
            if retorno == 0 :
                pos = meio
                return pos
            elif retorno == -1 :
                inicio = meio + 1
            elif retorno == 1:
                fim = meio-1
        
    #TODO: implemente
    def __lastIndexOf(self, prefixo):
        inicio = 0
        fim = self.numeroTermos-1        
        pos = -1
        #TODO: seu codigo aqui
        while inicio <= fim:
            meio = (inicio+fim)//2
            retorno = comparaPorPrefixo(termos[meio], prefixo)
            if retorno == 0 :
                pos = meio
                while pos < len(termos)-1 and comparaPorPrefixo(termos[pos+1], prefixo) == 0: #tá certa, mas pode melhorar
                        pos = pos + 1
                return pos
            
            elif retorno == -1:
                inicio = meio + 1
            elif retorno == 1 :
                fim = meio - 1  

    #TODO: implemente   
    def carregarDados(self,filename):
        if self.dadosCarregados:
            self.__apagarTermos()            
        #TODO: seu codigo aqui            
	arquivo = open(filename, 'r') #ESTÁ DANDO ERRO DE INDENTAÇÃO
	arquivo = arquivo.readlines() 
	numeroTermos = arquivo.pop(0).strip("\n") #guarda o primeiro termo do arquvio, que é a quantidade de palavras
	for item in arquivo:  
            item = item.strip().strip("\n").lower().split("\t")
            termos.append((item[1], int(item[0])))
        #arquivo nao esta sendo deletado
        self.termos.sort()
        self.dadosCarregados = True
    
    #TODO: implemente    
    def find(self, prefixo, qtd):
        lista_de_sugestoes = list()
        primeiro_indice = __firstIndexOf(prefixo)
        ultimo_indice = __lastIndexOf(prefixo)
        i = primeiro_indice
        while i < ultimo_indice :
            lista_de_sugestoes.inserirOrdenado(item, comparaPorPeso)
            i= i + 1
        while len(lista_de_sugestoes) > Qtd :
            lista_de_sugestoes.removerFim()
        for x in lista_de_sugestoes :
            x.__str__


    
